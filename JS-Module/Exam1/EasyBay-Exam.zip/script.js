function buttonAccept(element){
    var cookies = document.getElementById("cookiesDiv");
    cookies.style.display = "none";
}
function cambiarImagen(elemento) {
    elemento.src = "./img/succulents-2.jpg"; 
}
function imagenOrinigal(elemento) {
    elemento.src = "./img/succulents-1.jpg"; 
}
